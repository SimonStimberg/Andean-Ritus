<img src="https://cloud.githubusercontent.com/assets/86785/17715825/ef132730-6440-11e6-92d1-8480d51575f1.png">

## Usage
Download the repository and copy `externals/perlin.mxo` and `help/perlin.maxhelp` to somewhere in your Max/MSP filepath. If you are with Max 7 on OSX, it’ll be work if they are under `~/Documents/Max 7`.

## The story behind
https://omimi.tanigami.wtf/get-smooth-with-ken-perlin-on-max-msp-337630ecd2ad

